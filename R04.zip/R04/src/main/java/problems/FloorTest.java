package problems;
import problems.FloorBinarySearchImpl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class FloorTest {
	private Integer[] test1;
	
	public FloorBinarySearchImpl<> implementation;
	@Before
	public void setUp() throws Exception {
		
	}

	@Test
	public void test() {
		Integer[] i = new Integer[] {5,9,4,7};
		//assertEquals("",)
	}

}
