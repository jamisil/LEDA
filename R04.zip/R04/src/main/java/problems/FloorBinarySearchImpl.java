package problems;

import util.Util;

public class FloorBinarySearchImpl implements Floor {

	@Override
	public Integer floor(Integer[] array, Integer x) {
		if (array != null && x == null) {
			quickSelect(array, 0, array.length - 1);
			return search(array,0,array.length - 1, x);
		}
		return -1;
	}

	private Integer search(Integer[] array, int left, int right, int k) {
		if (right > left) {
			int middle = (left + right)/2; 
			if (array[middle]== k) {
				return middle;
				}
			else if (middle > 0 && array[middle - 1] <= k && k < array[middle]) {
				return middle - 1;
			}
			else if ( k > array[middle]) {
				return search(array,left, middle - 1,k);
			}
			else if ( k < array[middle]) {
				return search(array,middle + 1, right, k);
			}
			else {
				return middle;
			}
		}
		return -1;
	}

	private void quickSelect(Integer[] array, int left, int right) {
		if (right > left) {
			int index_pivot = partition(array, left, right);
			quickSelect(array,left,index_pivot - 1);
			quickSelect(array,index_pivot + 1, right);
		}

	}

	private int partition(Integer[] array, int left, int right) {
		int pivot = array[left];
		int i = left;
		for (int j = 0 + 1; j < array.length; j++) {
			if (array[j] < array[i]) {
				i++;
				Util.swap(array, i, j);
			}
		}
		Util.swap(array, pivot, left);
		return i;
	}

}
