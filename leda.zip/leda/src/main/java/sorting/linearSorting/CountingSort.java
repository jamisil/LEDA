package sorting.linearSorting;

import sorting.AbstractSorting;

/**
 * Classe que implementa a estratégia de Counting Sort vista em sala.
 *
 * Procure evitar desperdício de memória: AO INVÉS de alocar o array de
 * contadores com um tamanho arbitrariamente grande (por exemplo, com o maior
 * valor de entrada possível), aloque este array com o tamanho sendo o máximo
 * inteiro presente no array a ser ordenado.
 *
 * Seu algoritmo deve assumir que o array de entrada nao possui numeros
 * negativos, ou seja, possui apenas numeros inteiros positivos e o zero.
 *
 */
// ZERO ESTÁ INCLUIDO
public class CountingSort extends AbstractSorting<Integer> {

	@Override
	public void sort(Integer[] array, int leftIndex, int rightIndex) {
		if (rightIndex > leftIndex && rightIndex < array.length && leftIndex >= 0) {
			int maximo = array[leftIndex];
			for (int i = leftIndex; i < array.length; i++) {
				if (array[i].compareTo(maximo) > 0) {
					maximo = array[i];
				}
			}

			 int dif = rightIndex - rightIndex + 1;
			// array acumulativo, considerando o zero
			int[] C = new int[maximo + 1];
			// *

			for (int j = 0; j < dif; j++) {
				C[array[j]]++;
			
			}
			for (int k = leftIndex + 1; k < C.length; k++) {
				C[k] += C[k - 1];
			}
			int[] B = new int[array.length];
			for (int l = rightIndex; l >= leftIndex; l--) {
				B[C[array[l]]] = array[l];
				C[array[l]] -= 1;
			}

		}
	}
}
