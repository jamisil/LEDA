package banco;

public interface QualquerBanco {

	double saldoTotal();

	int numContas();

}