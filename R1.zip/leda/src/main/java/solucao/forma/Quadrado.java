package solucao.forma;

public class Quadrado extends Retangulo {
	//private double lado;

	public Quadrado(double lado) {
		super(lado, lado);
	}

}
