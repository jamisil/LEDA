package solucao.forma;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Circulo c = new Circulo(sc.nextDouble());
		System.out.println(c.area());
		Quadrado q = new Quadrado(sc.nextDouble());
		System.out.println(q.area());
		Retangulo r = new Retangulo(sc.nextDouble(),sc.nextDouble());
		System.out.println(r.area());
		Triangulo t = new Triangulo(sc.nextDouble(),sc.nextDouble());
		System.out.println(t.area());
	}

}
