package recursao;

public class Teste {

	public static void main(String[] args) {
		MetodosRecursivos m = new MetodosRecursivos();
		int a[] = new int[2];
		a[0] = 9;
		a[1] = 2;
		String[] s = new String[2];
		s[0] = "Jamy";
		s[1] = null;
		Object[] r = (Object[]) s;
		System.out.println(m.calcularSomaArray(a,2));
		System.out.println(m.calcularFatorial(5));
		System.out.println(m.calcularFibonacci(9));
		System.out.println(m.countNotNull(r, 1));

	}

}
