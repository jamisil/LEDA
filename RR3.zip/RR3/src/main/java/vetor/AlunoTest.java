package vetor;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AlunoTest {
	private Vetor<Aluno> v = new Vetor<Aluno>(2);
	private Vetor<Aluno> l = new Vetor<Aluno>(10);

	@Before
	public void setUp() throws Exception {

	}

	@Test
	public void testInserir() {
		l.inserir(new Aluno("usta", 7.5));
		assertEquals(new Aluno("usta", 7.5), (l.procurar(new Aluno("usta", 7.5))));
	}

	@Test
	public void testRemover() {
		assertFalse(v.isCheio());
		v.inserir(new Aluno("Josefa", 4));

	}

	@Test
	public void testProcurar() {
		l.inserir(new Aluno("lais", 4));
		assertEquals(new Aluno("lais",4),l.procurar(new Aluno("lais", 4)));
	}

	@Test
	public void testIsVazio() {
		assertTrue(v.isVazio());
		v.inserir(new Aluno("Josefa", 4));
		v.inserir(new Aluno("gal", 7));
		assertFalse(v.isVazio());
	}

	@Test
	public void testIsCheio() {
		assertFalse(v.isCheio());
		v.inserir(new Aluno("Josefa", 4));
		v.inserir(new Aluno("gal", 7));
		assertTrue(v.isCheio());
	}

}
