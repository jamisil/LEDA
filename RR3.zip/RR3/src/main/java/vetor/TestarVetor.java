package vetor;

public class TestarVetor {
//rascunho
	public static void main(String[] args) {
		Vetor v = new Vetor(2);
		System.out.println(v.isVazio());
		Aluno a = new Aluno("jose",5);
		v.inserir(a);
		System.out.println(v.isCheio());
		v.remover(a);
		System.out.println(v.isCheio());
	}
}
