package produto;

import solucao.produto.RepositorioProdutos;

public class RepositorioProdutosArray<T extends Produto> implements RepositorioProdutos<T> {
	// uso de generics
	private T[] produtos;
	private int index = -1;

	public RepositorioProdutosArray(int size) {
		super();
		this.produtos = (T[]) new Object[size];
	}

	private int procurarIndice(int codigo) {
		for (int i = 0; i < this.produtos.length; i++) {
			if (produtos[i].getCodigo() == codigo) {
				return i;
			}
		}
		return -1;

	}

	@Override
	public boolean existe(int codigo) {
		int i = procurarIndice(codigo);
		if (i == -1) {
			return false;
		}
		return true;

	}

	@Override
	public void inserir(T produto) {
		produtos[++index] = produto;
	}

	@Override
	public void atualizar(T produto) {
		int i = procurarIndice(produto.getCodigo());
		if (i != -1) {
			produtos[i] = produto;
		} else {
			throw new RuntimeException("Produto nao encontrado");
		}

	}

	@Override
	public void remover(int codigo) {
		int i = this.procurarIndice(codigo);
		if (i != -1) {
			produtos[i] = produtos[index];
			produtos[index] = null;
			index--;
		} else {
			throw new RuntimeException("Produto nao encontrado");
		}
	}

	@Override
	public T procurar(int codigo) {
		int i = this.procurarIndice(codigo);
		if (i != -1) {
			return this.produtos[i];
		}
		throw new RuntimeException("Produto nao encontrado");

	}

}
